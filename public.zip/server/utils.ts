import { Request, Response, NextFunction } from "express";
import { getSession, publicUser, state } from "./state";

export function getCookie(req: Request, name: string): string | undefined {
  const header = req.headers["cookie"];
  if (!header) return undefined;
  const parts = header.split(/;\s*/);
  for (const p of parts) {
    const [k, v] = p.split("=");
    if (k === name) return decodeURIComponent(v ?? "");
  }
  return undefined;
}

export function setCookie(res: Response, name: string, value: string, days = 7) {
  const maxAge = days * 24 * 60 * 60; // seconds
  const parts = [
    `${name}=${encodeURIComponent(value)}`,
    `Path=/` ,
    `HttpOnly`,
    `SameSite=Lax`,
    `Max-Age=${maxAge}`,
  ];
  if (process.env.NODE_ENV === "production") parts.push("Secure");
  res.setHeader("Set-Cookie", parts.join("; "));
}

export function clearCookie(res: Response, name: string) {
  res.setHeader("Set-Cookie", `${name}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0`);
}

export function requireAuth(req: Request, res: Response, next: NextFunction) {
  const sid = getCookie(req, "sid");
  const sess = getSession(sid);
  if (!sess) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  const user = state.users.get(sess.userId);
  if (!user) return res.status(401).json({ error: "Unauthorized" });
  (req as any).user = publicUser(user);
  (req as any).userPrivate = user;
  (req as any).session = sess;
  next();
}
