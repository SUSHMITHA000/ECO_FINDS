import { randomBytes, scryptSync, timingSafeEqual } from "crypto";
import type {
  AddToCartRequest,
  CartItem,
  Category,
  CreateProductRequest,
  ID,
  Product,
  Purchase,
  PurchaseItem,
  Session,
  UpdateProductRequest,
  User,
  UserPrivate,
} from "@shared/api";

function id(): ID {
  return randomBytes(16).toString("hex");
}

// In-memory stores
const users = new Map<ID, UserPrivate>();
const sessions = new Map<ID, Session>();
const products = new Map<ID, Product>();
const carts = new Map<ID, CartItem[]>(); // userId -> items
const purchases = new Map<ID, Purchase[]>(); // userId -> purchases

// Password hashing utilities (scrypt)
function hashPassword(password: string, salt?: string) {
  const s = salt ?? randomBytes(16).toString("hex");
  const hashBuf = scryptSync(password, s, 64);
  const hash = hashBuf.toString("hex");
  return { hash, salt: s };
}

function verifyPassword(password: string, hash: string, salt: string) {
  const { hash: computed } = hashPassword(password, salt);
  // constant-time compare
  return timingSafeEqual(Buffer.from(computed, "hex"), Buffer.from(hash, "hex"));
}

// Sessions
const SESSION_TTL_MS = 1000 * 60 * 60 * 24 * 7; // 7 days

export function createSession(userId: ID): Session {
  const s: Session = {
    id: id(),
    userId,
    createdAt: Date.now(),
    expiresAt: Date.now() + SESSION_TTL_MS,
  };
  sessions.set(s.id, s);
  return s;
}

export function getSession(sessionId: ID | undefined): Session | undefined {
  if (!sessionId) return undefined;
  const s = sessions.get(sessionId);
  if (!s) return undefined;
  if (s.expiresAt < Date.now()) {
    sessions.delete(sessionId);
    return undefined;
  }
  return s;
}

export function destroySession(sessionId: ID | undefined) {
  if (sessionId) sessions.delete(sessionId);
}

// Users
export function createUser(email: string, username: string, password: string): UserPrivate {
  if ([...users.values()].some((u) => u.email.toLowerCase() === email.toLowerCase())) {
    throw new Error("Email already in use");
  }
  const { hash, salt } = hashPassword(password);
  const u: UserPrivate = {
    id: id(),
    email,
    username,
    passwordHash: hash,
    passwordSalt: salt,
    createdAt: Date.now(),
  };
  users.set(u.id, u);
  return u;
}

export function findUserByEmail(email: string): UserPrivate | undefined {
  const e = email.toLowerCase();
  return [...users.values()].find((u) => u.email.toLowerCase() === e);
}

export function getUser(userId: ID | undefined): UserPrivate | undefined {
  if (!userId) return undefined;
  return users.get(userId);
}

export function publicUser(u: UserPrivate): User {
  const { passwordHash: _ph, passwordSalt: _ps, ...pub } = u;
  return pub;
}

export function updateUser(userId: ID, data: Partial<Pick<UserPrivate, "username">>): User {
  const u = users.get(userId);
  if (!u) throw new Error("User not found");
  if (data.username !== undefined) u.username = data.username;
  users.set(userId, u);
  return publicUser(u);
}

export function authenticate(email: string, password: string): UserPrivate | undefined {
  const u = findUserByEmail(email);
  if (!u) return undefined;
  if (!verifyPassword(password, u.passwordHash, u.passwordSalt)) return undefined;
  return u;
}

// Products
export function createProduct(ownerId: ID, req: CreateProductRequest): Product {
  const now = Date.now();
  const p: Product = {
    id: id(),
    ownerId,
    title: req.title,
    description: req.description,
    category: req.category,
    price: Math.max(0, Math.floor(req.price)),
    imageUrl:
      req.imageUrl?.trim() || "/placeholder.svg",
    createdAt: now,
    updatedAt: now,
  };
  products.set(p.id, p);
  return p;
}

export function updateProduct(ownerId: ID, productId: ID, req: UpdateProductRequest): Product {
  const p = products.get(productId);
  if (!p) throw new Error("Product not found");
  if (p.ownerId !== ownerId) throw new Error("Forbidden");
  if (req.title !== undefined) p.title = req.title;
  if (req.description !== undefined) p.description = req.description;
  if (req.category !== undefined) p.category = req.category as Category;
  if (req.price !== undefined) p.price = Math.max(0, Math.floor(req.price));
  if (req.imageUrl !== undefined) p.imageUrl = req.imageUrl.trim() || "/placeholder.svg";
  p.updatedAt = Date.now();
  products.set(p.id, p);
  return p;
}

export function deleteProduct(ownerId: ID, productId: ID) {
  const p = products.get(productId);
  if (!p) throw new Error("Product not found");
  if (p.ownerId !== ownerId) throw new Error("Forbidden");
  products.delete(productId);
}

export function getProduct(productId: ID): Product | undefined {
  return products.get(productId);
}

export function listProducts(opts: { q?: string; category?: Category | "All"; ownerId?: ID }) {
  let list = [...products.values()];
  if (opts.ownerId) list = list.filter((p) => p.ownerId === opts.ownerId);
  if (opts.category && opts.category !== "All") list = list.filter((p) => p.category === opts.category);
  if (opts.q) {
    const q = opts.q.toLowerCase();
    list = list.filter((p) => p.title.toLowerCase().includes(q));
  }
  // newest first
  list.sort((a, b) => b.createdAt - a.createdAt);
  return list;
}

// Cart
export function getCart(userId: ID): CartItem[] {
  return carts.get(userId) ?? [];
}

export function setCart(userId: ID, items: CartItem[]) {
  carts.set(userId, items);
}

export function addToCart(userId: ID, req: AddToCartRequest) {
  const p = products.get(req.productId);
  if (!p) throw new Error("Product not found");
  const items = getCart(userId);
  const idx = items.findIndex((i) => i.productId === req.productId);
  if (idx >= 0) {
    items[idx].quantity += req.quantity ?? 1;
  } else {
    items.push({ productId: req.productId, quantity: req.quantity ?? 1 });
  }
  setCart(userId, items);
}

export function removeFromCart(userId: ID, productId: ID) {
  const items = getCart(userId).filter((i) => i.productId !== productId);
  setCart(userId, items);
}

export function cartTotal(userId: ID): number {
  const items = getCart(userId);
  return items.reduce((sum, i) => {
    const p = products.get(i.productId);
    if (!p) return sum;
    return sum + p.price * i.quantity;
  }, 0);
}

// Checkout -> create purchase and clear cart
export function checkout(userId: ID): Purchase {
  const items = getCart(userId);
  if (items.length === 0) throw new Error("Cart is empty");
  const purchaseItems: PurchaseItem[] = items
    .map((i) => {
      const p = products.get(i.productId);
      if (!p) return undefined;
      return { productId: p.id, priceAtPurchase: p.price, quantity: i.quantity } as PurchaseItem;
    })
    .filter(Boolean) as PurchaseItem[];
  const pur: Purchase = {
    id: id(),
    userId,
    items: purchaseItems,
    total: purchaseItems.reduce((s, it) => s + it.priceAtPurchase * it.quantity, 0),
    createdAt: Date.now(),
  };
  const arr = purchases.get(userId) ?? [];
  arr.push(pur);
  purchases.set(userId, arr);
  // For simplicity, do not delete products on purchase
  setCart(userId, []);
  return pur;
}

export function listPurchases(userId: ID): Purchase[] {
  const arr = purchases.get(userId) ?? [];
  return [...arr].sort((a, b) => b.createdAt - a.createdAt);
}

// Seed demo data
(function seed() {
  try {
    const alice = createUser("alice@example.com", "Alice", "password");
    const bob = createUser("bob@example.com", "Bob", "password");
    const cats: Category[] = ["Electronics", "Fashion", "Home", "Books", "Sports", "Toys", "Other"];
    const sample = [
      { title: "Vintage Camera", price: 4500, category: "Electronics", ownerId: alice.id, imageUrl: "https://images.pexels.com/photos/1091294/pexels-photo-1091294.jpeg" },
      { title: "Denim Jacket", price: 2500, category: "Fashion", ownerId: bob.id, imageUrl: "https://images.pexels.com/photos/6069827/pexels-photo-6069827.jpeg" },
      { title: "Coffee Table", price: 5500, category: "Home", ownerId: alice.id, imageUrl: "https://images.pexels.com/photos/1015568/pexels-photo-1015568.jpeg" },
      { title: "Sci-Fi Novel", price: 800, category: "Books", ownerId: bob.id, imageUrl: "https://images.pexels.com/photos/4218864/pexels-photo-4218864.jpeg" },
      { title: "Yoga Mat", price: 1200, category: "Sports", ownerId: alice.id, imageUrl: "https://images.pexels.com/photos/4793318/pexels-photo-4793318.jpeg" },
    ];
    for (const s of sample) {
      createProduct(s.ownerId, {
        title: s.title,
        description: `${s.title} in great condition. Second-hand, sustainable choice.`,
        category: s.category as Category,
        price: s.price,
        imageUrl: s.imageUrl,
      });
    }

    const more = [
      { title: "Over-Ear Headphones", price: 6500, category: "Electronics", imageUrl: "https://images.pexels.com/photos/8000610/pexels-photo-8000610.jpeg" },
      { title: "Wireless Earbuds", price: 3500, category: "Electronics", imageUrl: "https://images.pexels.com/photos/350794/pexels-photo-350794.jpeg" },
      { title: "Smartphone", price: 15000, category: "Electronics", imageUrl: "https://images.pexels.com/photos/25254693/pexels-photo-25254693.jpeg" },
      { title: "Laptop", price: 45000, category: "Electronics", imageUrl: "https://images.pexels.com/photos/4065876/pexels-photo-4065876.jpeg" },
      { title: "Game Controller", price: 3500, category: "Electronics", imageUrl: "https://images.pexels.com/photos/4523001/pexels-photo-4523001.jpeg" },
      { title: "Smartwatch", price: 12000, category: "Electronics", imageUrl: "https://images.pexels.com/photos/7552326/pexels-photo-7552326.jpeg" },
      { title: "Bluetooth Speaker", price: 4000, category: "Electronics", imageUrl: "https://images.pexels.com/photos/1034653/pexels-photo-1034653.jpeg" },
      { title: "Camera Lens", price: 18000, category: "Electronics", imageUrl: "https://images.pexels.com/photos/46282/lens-technical-camera-photography-46282.jpeg" },
      { title: "Tripod", price: 5000, category: "Electronics", imageUrl: "https://images.pexels.com/photos/17094499/pexels-photo-17094499.jpeg" },

      { title: "Winter Coat", price: 8000, category: "Fashion", imageUrl: "https://images.pexels.com/photos/6567555/pexels-photo-6567555.jpeg" },
      { title: "Sneakers", price: 6000, category: "Fashion", imageUrl: "https://images.pexels.com/photos/7289713/pexels-photo-7289713.jpeg" },
      { title: "Backpack", price: 4500, category: "Fashion", imageUrl: "https://images.pexels.com/photos/2962082/pexels-photo-2962082.jpeg" },
      { title: "Sunglasses", price: 2500, category: "Fashion", imageUrl: "https://images.pexels.com/photos/9595285/pexels-photo-9595285.jpeg" },
      { title: "Summer Dress", price: 5500, category: "Fashion", imageUrl: "https://images.pexels.com/photos/30797176/pexels-photo-30797176.jpeg" },

      { title: "Table Lamp", price: 3000, category: "Home", imageUrl: "https://images.pexels.com/photos/1918291/pexels-photo-1918291.jpeg" },
      { title: "Modern Sofa", price: 25000, category: "Home", imageUrl: "https://images.pexels.com/photos/279607/pexels-photo-279607.jpeg" },
      { title: "Dining Chair", price: 7000, category: "Home", imageUrl: "https://images.pexels.com/photos/271696/pexels-photo-271696.jpeg" },
      { title: "Area Rug", price: 9000, category: "Home", imageUrl: "https://images.pexels.com/photos/6956622/pexels-photo-6956622.jpeg" },
      { title: "Stand Mixer", price: 11000, category: "Home", imageUrl: "https://images.pexels.com/photos/5908003/pexels-photo-5908003.jpeg" },
      { title: "Coffee Maker", price: 9000, category: "Home", imageUrl: "https://images.pexels.com/photos/6205605/pexels-photo-6205605.jpeg" },
      { title: "Potted Plant", price: 2500, category: "Home", imageUrl: "https://images.pexels.com/photos/7185835/pexels-photo-7185835.jpeg" },

      { title: "Book Bundle", price: 1200, category: "Books", imageUrl: "https://images.pexels.com/photos/6281902/pexels-photo-6281902.jpeg" },
      { title: "Home Cookbook", price: 1500, category: "Books", imageUrl: "https://images.pexels.com/photos/6373289/pexels-photo-6373289.jpeg" },

      { title: "Teddy Bear", price: 1800, category: "Toys", imageUrl: "https://images.pexels.com/photos/14585409/pexels-photo-14585409.jpeg" },
      { title: "LEGO Mini Figure", price: 1500, category: "Toys", imageUrl: "https://images.pexels.com/photos/8365833/pexels-photo-8365833.jpeg" },
      { title: "Board Game Set", price: 2500, category: "Toys", imageUrl: "https://images.pexels.com/photos/776654/pexels-photo-776654.jpeg" },

      { title: "Tennis Racket", price: 7000, category: "Sports", imageUrl: "https://images.pexels.com/photos/10667388/pexels-photo-10667388.jpeg" },
      { title: "Yoga Blocks Set", price: 2200, category: "Sports", imageUrl: "https://images.pexels.com/photos/7055749/pexels-photo-7055749.jpeg" },
      { title: "Basketball", price: 2800, category: "Sports", imageUrl: "https://images.pexels.com/photos/31174804/pexels-photo-31174804.jpeg" },

      { title: "Acoustic Guitar", price: 12000, category: "Other", imageUrl: "https://images.pexels.com/photos/12446398/pexels-photo-12446398.jpeg" },
    ];

    more.forEach((m, i) => {
      const ownerId2 = i % 2 === 0 ? alice.id : bob.id;
      createProduct(ownerId2, {
        title: m.title,
        description: `${m.title} pre-owned, great condition. Sustainable choice.`,
        category: m.category as Category,
        price: m.price,
        imageUrl: m.imageUrl,
      });
    });

  } catch {}
})();

export const state = {
  users,
  sessions,
  products,
  carts,
  purchases,
};
