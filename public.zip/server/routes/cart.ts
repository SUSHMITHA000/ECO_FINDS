import { RequestHandler } from "express";
import { AddToCartRequest } from "@shared/api";
import { addToCart, cartTotal, checkout, getCart, listPurchases, removeFromCart, state } from "../state";
import { requireAuth } from "../utils";

export const getMyCart: RequestHandler[] = [requireAuth, (req, res) => {
  const uid = (req as any).user.id as string;
  const items = getCart(uid).map((i) => ({ ...i, product: state.products.get(i.productId)! }));
  res.json({ items, total: cartTotal(uid) });
}];

export const addItem: RequestHandler[] = [requireAuth, (req, res) => {
  const uid = (req as any).user.id as string;
  const body = req.body as AddToCartRequest;
  try {
    addToCart(uid, body);
    const items = getCart(uid).map((i) => ({ ...i, product: state.products.get(i.productId)! }));
    res.status(201).json({ items, total: cartTotal(uid) });
  } catch (e: any) {
    res.status(400).json({ error: e?.message ?? 'Add to cart failed' });
  }
}];

export const removeItem: RequestHandler[] = [requireAuth, (req, res) => {
  const uid = (req as any).user.id as string;
  const id = req.params.id;
  removeFromCart(uid, id);
  const items = getCart(uid).map((i) => ({ ...i, product: state.products.get(i.productId)! }));
  res.json({ items, total: cartTotal(uid) });
}];

export const doCheckout: RequestHandler[] = [requireAuth, (req, res) => {
  const uid = (req as any).user.id as string;
  try {
    const p = checkout(uid);
    res.json({ purchase: p });
  } catch (e: any) {
    res.status(400).json({ error: e?.message ?? 'Checkout failed' });
  }
}];

export const getPurchases: RequestHandler[] = [requireAuth, (req, res) => {
  const uid = (req as any).user.id as string;
  const arr = listPurchases(uid);
  res.json({ purchases: arr });
}];
