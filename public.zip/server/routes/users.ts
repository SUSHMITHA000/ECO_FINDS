import { RequestHandler } from "express";
import { UpdateProfileRequest } from "@shared/api";
import { requireAuth } from "../utils";
import { updateUser } from "../state";

export const getMe: RequestHandler[] = [requireAuth, (req, res) => {
  const user = (req as any).user;
  res.json({ user });
}];

export const updateMe: RequestHandler[] = [requireAuth, (req, res) => {
  const u = (req as any).user;
  const body = req.body as UpdateProfileRequest;
  try {
    const updated = updateUser(u.id, { username: body.username });
    res.json({ user: updated });
  } catch (e: any) {
    res.status(400).json({ error: e?.message ?? 'Update failed' });
  }
}];
