import { RequestHandler } from "express";
import { AuthLoginRequest, AuthRegisterRequest, AuthResponse } from "@shared/api";
import { authenticate, createSession, createUser, publicUser, state } from "../state";
import { clearCookie, getCookie, setCookie } from "../utils";

export const register: RequestHandler = (req, res) => {
  const body = req.body as AuthRegisterRequest;
  if (!body?.email || !body?.password || !body?.username) {
    return res.status(400).json({ error: "Missing fields" });
  }
  try {
    const u = createUser(body.email, body.username, body.password);
    const sess = createSession(u.id);
    setCookie(res, "sid", sess.id);
    const resp: AuthResponse = { user: publicUser(u) };
    res.status(201).json(resp);
  } catch (e: any) {
    res.status(400).json({ error: e?.message ?? "Registration failed" });
  }
};

export const login: RequestHandler = (req, res) => {
  const body = req.body as AuthLoginRequest;
  if (!body?.email || !body?.password) return res.status(400).json({ error: "Missing fields" });
  const u = authenticate(body.email, body.password);
  if (!u) return res.status(401).json({ error: "Invalid credentials" });
  const sess = createSession(u.id);
  setCookie(res, "sid", sess.id);
  const resp: AuthResponse = { user: publicUser(u) };
  res.json(resp);
};

export const me: RequestHandler = (req, res) => {
  const sid = getCookie(req, "sid");
  const sess = sid ? state.sessions.get(sid) : undefined;
  if (!sess) return res.status(200).json({ user: null });
  const u = sess ? state.users.get(sess.userId) : undefined;
  if (!u) return res.status(200).json({ user: null });
  res.json({ user: publicUser(u) });
};

export const logout: RequestHandler = (req, res) => {
  clearCookie(res, "sid");
  res.json({ ok: true });
};
