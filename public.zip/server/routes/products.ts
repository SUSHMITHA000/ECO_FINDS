import { RequestHandler } from "express";
import { CreateProductRequest, ListProductsQuery, ListProductsResponse, UpdateProductRequest } from "@shared/api";
import { requireAuth } from "../utils";
import { createProduct, deleteProduct, getProduct, listProducts, updateProduct } from "../state";

export const listAll: RequestHandler = (req, res) => {
  const q = (req.query.q as string) || undefined;
  const category = (req.query.category as any) || undefined;
  const mine = (req.query.mine as string) === "true";
  const ownerId = mine && (req as any).user ? (req as any).user.id : undefined;
  const data = listProducts({ q, category, ownerId });
  const resp: ListProductsResponse = { products: data };
  res.json(resp);
};

export const listMine: RequestHandler[] = [requireAuth, (req, res) => {
  const q = (req.query.q as string) || undefined;
  const category = (req.query.category as any) || undefined;
  const ownerId = (req as any).user.id as string;
  const data = listProducts({ q, category, ownerId });
  res.json({ products: data });
}];

export const create: RequestHandler[] = [requireAuth, (req, res) => {
  const body = req.body as CreateProductRequest;
  if (!body?.title || !body?.description || !body?.category || typeof body?.price !== 'number')
    return res.status(400).json({ error: 'Missing fields' });
  try {
    const p = createProduct((req as any).user.id, body);
    res.status(201).json({ product: p });
  } catch (e: any) {
    res.status(400).json({ error: e?.message ?? 'Create failed' });
  }
}];

export const read: RequestHandler = (req, res) => {
  const p = getProduct(req.params.id);
  if (!p) return res.status(404).json({ error: 'Not found' });
  res.json({ product: p });
};

export const update: RequestHandler[] = [requireAuth, (req, res) => {
  const body = req.body as UpdateProductRequest;
  try {
    const p = updateProduct((req as any).user.id, req.params.id, body);
    res.json({ product: p });
  } catch (e: any) {
    res.status(400).json({ error: e?.message ?? 'Update failed' });
  }
}];

export const remove: RequestHandler[] = [requireAuth, (req, res) => {
  try {
    deleteProduct((req as any).user.id, req.params.id);
    res.json({ ok: true });
  } catch (e: any) {
    res.status(400).json({ error: e?.message ?? 'Delete failed' });
  }
}];
