import "dotenv/config";
import express from "express";
import cors from "cors";
import { handleDemo } from "./routes/demo";
import * as Auth from "./routes/auth";
import * as Users from "./routes/users";
import * as Products from "./routes/products";
import * as Cart from "./routes/cart";

export function createServer() {
  const app = express();

  // Middleware
  app.use(cors());
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // Health/demo
  app.get("/api/ping", (_req, res) => {
    const ping = process.env.PING_MESSAGE ?? "ping";
    res.json({ message: ping });
  });
  app.get("/api/demo", handleDemo);

  // Auth
  app.post("/api/auth/register", Auth.register);
  app.post("/api/auth/login", Auth.login);
  app.get("/api/auth/me", Auth.me);
  app.post("/api/auth/logout", Auth.logout);

  // Users
  app.get("/api/users/me", Users.getMe);
  app.put("/api/users/me", Users.updateMe);

  // Products
  app.get("/api/products", Products.listAll);
  app.get("/api/products/mine", Products.listMine);
  app.post("/api/products", Products.create);
  app.get("/api/products/:id", Products.read);
  app.put("/api/products/:id", Products.update);
  app.delete("/api/products/:id", Products.remove);

  // Cart & Purchases
  app.get("/api/cart", Cart.getMyCart);
  app.post("/api/cart", Cart.addItem);
  app.delete("/api/cart/:id", Cart.removeItem);
  app.post("/api/checkout", Cart.doCheckout);
  app.get("/api/purchases", Cart.getPurchases);

  return app;
}
