import { Link } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import type { Product } from "@shared/api";
import { useAuth } from "@/hooks/useAuth";
import { ShoppingCart } from "lucide-react";
import { useCart } from "@/hooks/useCart";

export function currency(cents: number) {
  return new Intl.NumberFormat(undefined, { style: 'currency', currency: 'USD' }).format(cents / 100);
}

export function ProductCard({ p, onAdded }: { p: Product; onAdded?: ()=>void }) {
  const { user } = useAuth();
  const { add } = useCart();
  const canEdit = user?.id === p.ownerId;
  const quickAdd = async (e?: React.MouseEvent)=>{ e?.preventDefault(); await add(p.id, 1); onAdded?.(); };
  return (
    <Card className="overflow-hidden group" onClick={(e)=>{ const t = e.target as HTMLElement; if (t.closest('button,a')) return; quickAdd(); }}>
      <img src={p.imageUrl} alt={p.title} className="h-48 w-full object-cover transition group-hover:scale-[1.02]" />
      <CardHeader className="p-4">
        <CardTitle className="text-base line-clamp-1">{p.title}</CardTitle>
      </CardHeader>
      <CardContent className="p-4 pt-0 flex items-center justify-between">
        <div className="text-emerald-700 font-semibold">{currency(p.price)}</div>
        {canEdit ? (
          <Link to={`/edit/${p.id}`}><Button size="sm" variant="outline">Edit</Button></Link>
        ) : (
          <Button size="sm" className="gap-1.5" onClick={quickAdd}><ShoppingCart className="size-4"/>Add to cart</Button>
        )}
      </CardContent>
    </Card>
  );
}
