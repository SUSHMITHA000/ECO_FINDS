import { Link, NavLink, useLocation } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { ShoppingCart, LogIn, LogOut, User, PlusCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import { useCart } from "@/hooks/useCart";

export function Layout({ children }: { children: React.ReactNode }) {
  const { user, logout } = useAuth();
  const { count } = useCart();
  const loc = useLocation();
  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 to-lime-50 text-foreground">
      <header className="border-b bg-white/70 backdrop-blur sticky top-0 z-30">
        <div className="container flex h-16 items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <span className="inline-flex h-8 w-8 items-center justify-center rounded-md bg-emerald-600 text-white font-bold">EF</span>
            <span className="text-xl font-extrabold tracking-tight">EcoFinds</span>
          </Link>
          <nav className="hidden md:flex items-center gap-6">
            <NavLink className={({isActive})=>cn("text-sm font-medium hover:text-emerald-700", isActive && "text-emerald-700") } to="/">Browse</NavLink>
            {user && <NavLink className={({isActive})=>cn("text-sm font-medium hover:text-emerald-700", isActive && "text-emerald-700") } to="/my-listings">My Listings</NavLink>}
            {user && <NavLink className={({isActive})=>cn("text-sm font-medium hover:text-emerald-700", isActive && "text-emerald-700") } to="/purchases">Purchases</NavLink>}
          </nav>
          <div className="flex items-center gap-2">
            {user ? (
              <>
                <NavLink to="/add" className="hidden sm:block"><Button variant="secondary" className="gap-2"><PlusCircle className="size-4"/>List item</Button></NavLink>
                <NavLink to="/cart" className="relative">
                  <Button variant="outline" size="icon" aria-label="Cart"><ShoppingCart/></Button>
                  {count > 0 && <span className="absolute -right-2 -top-2 inline-flex h-5 min-w-5 items-center justify-center rounded-full bg-emerald-600 px-1 text-xs text-white">{count}</span>}
                </NavLink>
                <NavLink to="/dashboard"><Button variant="ghost" size="icon" aria-label="Profile"><User/></Button></NavLink>
                <Button variant="ghost" onClick={logout} aria-label="Log out"><LogOut className="mr-2"/>Logout</Button>
              </>
            ) : (
              <NavLink to="/login"><Button className="gap-2"><LogIn className="size-4"/>Login</Button></NavLink>
            )}
          </div>
        </div>
      </header>
      <main className="container py-8">{children}</main>
      <footer className="border-t bg-white/50">
        <div className="container py-6 text-sm text-muted-foreground">© {new Date().getFullYear()} EcoFinds · Buy pre-loved, live green.</div>
      </footer>
    </div>
  );
}
