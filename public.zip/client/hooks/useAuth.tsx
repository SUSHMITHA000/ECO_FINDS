import { createContext, useContext, useEffect, useState } from "react";
import type { User } from "@shared/api";
import { api } from "@/lib/api";

interface AuthCtx {
  user: User | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (email: string, username: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
}

const Ctx = createContext<AuthCtx | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.me().then((r) => { setUser(r.user); setLoading(false); }).catch(() => setLoading(false));
  }, []);

  const login = async (email: string, password: string) => {
    const r = await api.login({ email, password });
    setUser(r.user);
    // merge guest cart
    try { const { mergeGuestCartToServer } = await import("@/hooks/useCart"); await mergeGuestCartToServer(); } catch {}
  };

  const register = async (email: string, username: string, password: string) => {
    const r = await api.register({ email, username, password });
    setUser(r.user);
    try { const { mergeGuestCartToServer } = await import("@/hooks/useCart"); await mergeGuestCartToServer(); } catch {}
  };

  const logout = async () => {
    await api.logout();
    setUser(null);
  };

  return <Ctx.Provider value={{ user, loading, login, register, logout }}>{children}</Ctx.Provider>;
}

export function useAuth() {
  const v = useContext(Ctx);
  if (!v) throw new Error("useAuth must be used within AuthProvider");
  return v;
}
