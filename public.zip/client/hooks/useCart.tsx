import { createContext, useContext, useEffect, useMemo, useState } from "react";
import { api } from "@/lib/api";
import { useAuth } from "@/hooks/useAuth";

export interface CartCtx {
  count: number;
  add: (productId: string, qty?: number) => Promise<void>;
  remove: (productId: string) => Promise<void>;
  refresh: () => Promise<void>;
}

const KEY = "guest_cart";

function readGuest(): Record<string, number> {
  try { return JSON.parse(localStorage.getItem(KEY) || "{}"); } catch { return {}; }
}
function writeGuest(map: Record<string, number>) {
  localStorage.setItem(KEY, JSON.stringify(map));
}
function clearGuest() { localStorage.removeItem(KEY); }
export function getGuestMap() { return readGuest(); }

const Ctx = createContext<CartCtx | undefined>(undefined);

export function CartProvider({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  const [count, setCount] = useState(0);

  const refresh = async () => {
    if (user) {
      try {
        const r = await api.getCart();
        setCount(r.items.reduce((s, i) => s + i.quantity, 0));
      } catch { setCount(0); }
    } else {
      const map = readGuest();
      setCount(Object.values(map).reduce((s, n) => s + n, 0));
    }
  };

  useEffect(() => { refresh(); }, [user?.id]);

  const add = async (productId: string, qty = 1) => {
    if (user) {
      await api.addToCart({ productId, quantity: qty });
      await refresh();
    } else {
      const map = readGuest();
      map[productId] = (map[productId] || 0) + qty;
      writeGuest(map);
      await refresh();
    }
  };

  const remove = async (productId: string) => {
    if (user) {
      await api.removeFromCart(productId);
      await refresh();
    } else {
      const map = readGuest();
      delete map[productId];
      writeGuest(map);
      await refresh();
    }
  };

  const value = useMemo(() => ({ count, add, remove, refresh }), [count]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useCart() {
  const v = useContext(Ctx);
  if (!v) throw new Error("useCart must be used within CartProvider");
  return v;
}

// helper to merge guest cart post-login
export async function mergeGuestCartToServer() {
  const map = readGuest();
  const entries = Object.entries(map);
  for (const [pid, q] of entries) {
    try { await api.addToCart({ productId: pid, quantity: q }); } catch {}
  }
  clearGuest();
}
