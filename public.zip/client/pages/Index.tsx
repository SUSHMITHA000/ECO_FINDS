import { useEffect, useMemo, useState } from "react";
import { Layout } from "@/components/Layout";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { ProductCard } from "@/components/ProductCard";
import { api } from "@/lib/api";
import { CATEGORIES } from "@/lib/constants";
import type { Product } from "@shared/api";
import { PlusCircle, Search } from "lucide-react";
import { Link } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";

export default function Index() {
  const [q, setQ] = useState("");
  const [category, setCategory] = useState<(typeof CATEGORIES)[number]>("All");
  const [products, setProducts] = useState<Product[]>([]);
  const { user } = useAuth();

  const load = async () => {
    const r = await api.listProducts({ q, category: category === "All" ? undefined : category });
    setProducts(r.products);
  };

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [category]);

  const filteredCount = useMemo(() => products.length, [products]);

  return (
    <Layout>
      <div className="mb-6 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
        <h1 className="text-3xl font-extrabold tracking-tight">Discover pre-loved treasures</h1>
        {user && (
          <Link to="/add"><Button className="gap-2"><PlusCircle className="size-4"/>Add Listing</Button></Link>
        )}
      </div>
      <div className="grid gap-3 sm:grid-cols-3 mb-6">
        <div className="sm:col-span-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground size-4"/>
            <Input value={q} onChange={(e)=>setQ(e.target.value)} placeholder="Search by title" className="pl-9"/>
          </div>
        </div>
        <Select value={category} onValueChange={(v)=>setCategory(v as any)}>
          <SelectTrigger><SelectValue placeholder="Category"/></SelectTrigger>
          <SelectContent>
            {CATEGORIES.map((c)=> <SelectItem key={c} value={c}>{c}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>
      <div className="mb-4 flex items-center justify-between text-sm text-muted-foreground">
        <span>{filteredCount} results</span>
        <Button variant="outline" onClick={load}>Refresh</Button>
      </div>
      <div className="grid gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {products.map((p)=> <ProductCard key={p.id} p={p} onAdded={load}/>) }
      </div>
      {!user && (
        <div className="mt-10 rounded-xl border bg-white p-6 text-center">
          <p className="text-muted-foreground">Want to sell your items? Create an account to list and manage your pre-loved goods.</p>
          <div className="mt-4"><Link to="/login"><Button>Get Started</Button></Link></div>
        </div>
      )}
    </Layout>
  );
}
