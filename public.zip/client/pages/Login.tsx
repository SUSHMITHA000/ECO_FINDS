import { useState } from "react";
import { Layout } from "@/components/Layout";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { useNavigate } from "react-router-dom";

export default function Login() {
  const [mode, setMode] = useState<'login'|'signup'>('login');
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [username, setUsername] = useState("");
  const [error, setError] = useState<string | null>(null);
  const { login, register } = useAuth();
  const nav = useNavigate();

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      if (mode === 'login') await login(email, password);
      else await register(email, username, password);
      nav('/');
    } catch (e: any) {
      setError(e?.message ?? 'Failed');
    }
  };

  return (
    <Layout>
      <div className="mx-auto max-w-md">
        <h1 className="text-3xl font-extrabold tracking-tight mb-6">{mode === 'login' ? 'Welcome back' : 'Create your account'}</h1>
        <form onSubmit={submit} className="space-y-4">
          <div>
            <label className="text-sm font-medium">Email</label>
            <Input type="email" value={email} onChange={(e)=>setEmail(e.target.value)} required />
          </div>
          {mode === 'signup' && (
            <div>
              <label className="text-sm font-medium">Username</label>
              <Input value={username} onChange={(e)=>setUsername(e.target.value)} required />
            </div>
          )}
          <div>
            <label className="text-sm font-medium">Password</label>
            <Input type="password" value={password} onChange={(e)=>setPassword(e.target.value)} required minLength={4} />
          </div>
          {error && <p className="text-destructive text-sm">{error}</p>}
          <Button type="submit" className="w-full">{mode === 'login' ? 'Login' : 'Sign Up'}</Button>
        </form>
        <div className="mt-4 text-center text-sm">
          {mode === 'login' ? (
            <button className="text-primary underline" onClick={()=>setMode('signup')}>No account? Sign up</button>
          ) : (
            <button className="text-primary underline" onClick={()=>setMode('login')}>Already have an account? Log in</button>
          )}
        </div>
      </div>
    </Layout>
  );
}
