import { useEffect, useState } from "react";
import { Layout } from "@/components/Layout";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CATEGORIES } from "@/lib/constants";
import { api } from "@/lib/api";
import { useNavigate, useParams } from "react-router-dom";

export default function AddEditProduct() {
  const { id } = useParams();
  const isEdit = Boolean(id);
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState<string>("Electronics");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState(0);
  const [imageUrl, setImageUrl] = useState("");
  const [error, setError] = useState<string | null>(null);
  const nav = useNavigate();

  useEffect(()=>{
    if (isEdit) {
      api.getProduct(id!).then(r=>{
        const p = r.product;
        setTitle(p.title); setCategory(p.category); setDescription(p.description); setPrice(p.price); setImageUrl(p.imageUrl);
      }).catch(()=>{});
    }
  },[id,isEdit]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      if (isEdit) await api.updateProduct(id!, { title, category: category as any, description, price, imageUrl });
      else await api.createProduct({ title, category: category as any, description, price, imageUrl });
      nav(isEdit ? "/my-listings" : "/");
    } catch (e: any) { setError(e?.message ?? 'Failed'); }
  };

  return (
    <Layout>
      <div className="mx-auto max-w-2xl">
        <h1 className="text-3xl font-extrabold tracking-tight mb-6">{isEdit ? 'Edit Product' : 'Add New Product'}</h1>
        <form onSubmit={submit} className="space-y-4">
          <div>
            <label className="text-sm font-medium">Product Title</label>
            <Input value={title} onChange={(e)=>setTitle(e.target.value)} required />
          </div>
          <div>
            <label className="text-sm font-medium">Category</label>
            <Select value={category} onValueChange={(v)=>setCategory(v)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {CATEGORIES.filter(c=>c!=="All").map((c)=>(<SelectItem key={c} value={c}>{c}</SelectItem>))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="text-sm font-medium">Description</label>
            <Textarea value={description} onChange={(e)=>setDescription(e.target.value)} required rows={4}/>
          </div>
          <div>
            <label className="text-sm font-medium">Price (cents)</label>
            <Input type="number" min={0} value={price} onChange={(e)=>setPrice(parseInt(e.target.value||'0'))} required />
          </div>
          <div>
            <label className="text-sm font-medium">Image URL</label>
            <Input value={imageUrl} onChange={(e)=>setImageUrl(e.target.value)} placeholder="/placeholder.svg" />
          </div>
          {error && <p className="text-destructive text-sm">{error}</p>}
          <Button type="submit">{isEdit ? 'Save Changes' : 'Submit Listing'}</Button>
        </form>
      </div>
    </Layout>
  );
}
