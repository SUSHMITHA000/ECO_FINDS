import { useLocation, Link } from "react-router-dom";
import { useEffect } from "react";
import { Layout } from "@/components/Layout";
import { Button } from "@/components/ui/button";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error("404", location.pathname);
  }, [location.pathname]);

  return (
    <Layout>
      <div className="py-32 text-center">
        <h1 className="text-5xl font-extrabold tracking-tight mb-2">404</h1>
        <p className="text-muted-foreground mb-6">Page not found</p>
        <Link to="/"><Button>Go Home</Button></Link>
      </div>
    </Layout>
  );
};

export default NotFound;
