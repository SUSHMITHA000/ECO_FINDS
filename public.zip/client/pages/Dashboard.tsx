import { useEffect, useState } from "react";
import { Layout } from "@/components/Layout";
import { useAuth } from "@/hooks/useAuth";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { api } from "@/lib/api";

export default function Dashboard() {
  const { user } = useAuth();
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<string | null>(null);

  useEffect(()=>{ if (user) { setUsername(user.username); setEmail(user.email); } }, [user]);

  const save = async ()=>{
    await api.updateProfile({ username });
    setStatus("Saved");
    setTimeout(()=>setStatus(null), 1500);
  };

  return (
    <Layout>
      <div className="mx-auto max-w-xl">
        <h1 className="text-3xl font-extrabold tracking-tight mb-6">Your Profile</h1>
        <div className="space-y-4">
          <div>
            <label className="text-sm font-medium">Email</label>
            <Input value={email} readOnly />
          </div>
          <div>
            <label className="text-sm font-medium">Username</label>
            <Input value={username} onChange={(e)=>setUsername(e.target.value)} />
          </div>
          <Button onClick={save}>Save</Button>
          {status && <span className="text-sm text-emerald-700 ml-3">{status}</span>}
        </div>
      </div>
    </Layout>
  );
}
