import { useEffect, useState } from "react";
import { Layout } from "@/components/Layout";
import { Button } from "@/components/ui/button";
import { ProductCard } from "@/components/ProductCard";
import { api } from "@/lib/api";
import type { Product } from "@shared/api";
import { Link } from "react-router-dom";

export default function MyListings() {
  const [products, setProducts] = useState<Product[]>([]);
  const load = async () => {
    const r = await api.listProducts({ mine: true });
    setProducts(r.products);
  };
  useEffect(()=>{ load(); }, []);
  return (
    <Layout>
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-3xl font-extrabold tracking-tight">My Listings</h1>
        <Link to="/add"><Button>Add New</Button></Link>
      </div>
      <div className="grid gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {products.map((p)=> <ProductCard key={p.id} p={p} onAdded={load} />)}
      </div>
      {products.length === 0 && (
        <div className="text-center text-muted-foreground">No listings yet.</div>
      )}
    </Layout>
  );
}
