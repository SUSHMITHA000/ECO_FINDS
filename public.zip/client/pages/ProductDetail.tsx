import { useEffect, useState } from "react";
import { Layout } from "@/components/Layout";
import { api } from "@/lib/api";
import type { Product } from "@shared/api";
import { useParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { currency } from "@/components/ProductCard";
import { ShoppingCart } from "lucide-react";
import { useCart } from "@/hooks/useCart";

export default function ProductDetail() {
  const { id } = useParams();
  const [p, setP] = useState<Product | null>(null);
  const [error, setError] = useState<string | null>(null);
  useEffect(()=>{ if (id) api.getProduct(id).then(r=> setP(r.product)).catch(e=> setError('Not found')); }, [id]);
  if (error) return <Layout><div className="text-destructive">{error}</div></Layout>;
  if (!p) return <Layout></Layout>;
  const { add } = useCart();
  return (
    <Layout>
      <div className="grid gap-8 md:grid-cols-2">
        <img src={p.imageUrl} alt={p.title} className="w-full rounded-lg border object-cover max-h-[480px]" />
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight mb-2">{p.title}</h1>
          <div className="text-xl text-emerald-700 font-semibold mb-4">{currency(p.price)}</div>
          <div className="text-sm text-muted-foreground mb-1">Category</div>
          <div className="mb-6">{p.category}</div>
          <div className="text-sm text-muted-foreground mb-1">Description</div>
          <p className="mb-6 leading-relaxed">{p.description}</p>
          <Button className="gap-1.5" onClick={async ()=>{ await add(p.id, 1); }}><ShoppingCart className="size-4"/>Add to cart</Button>
        </div>
      </div>
    </Layout>
  );
}
