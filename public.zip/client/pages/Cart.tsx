import { useEffect, useState } from "react";
import { Layout } from "@/components/Layout";
import { api } from "@/lib/api";
import type { CartResponse, Product } from "@shared/api";
import { Button } from "@/components/ui/button";
import { currency } from "@/components/ProductCard";
import { useAuth } from "@/hooks/useAuth";
import { getGuestMap, useCart } from "@/hooks/useCart";
import { Link, useNavigate } from "react-router-dom";

export default function Cart() {
  const { user } = useAuth();
  const { remove, refresh } = useCart();
  const [serverData, setServerData] = useState<CartResponse | null>(null);
  const [guestItems, setGuestItems] = useState<{ product: Product; quantity: number }[]>([]);
  const [guestTotal, setGuestTotal] = useState(0);
  const nav = useNavigate();

  const load = async () => {
    if (user) {
      const r = await api.getCart();
      setServerData(r);
    } else {
      const map = getGuestMap();
      const ids = Object.keys(map);
      const items: { product: Product; quantity: number }[] = [];
      for (const id of ids) {
        try {
          const r = await api.getProduct(id);
          items.push({ product: r.product, quantity: map[id] });
        } catch {}
      }
      setGuestItems(items);
      setGuestTotal(items.reduce((s, it) => s + it.product.price * it.quantity, 0));
    }
  };

  useEffect(() => { load(); }, [user?.id]);

  const total = user ? serverData?.total ?? 0 : guestTotal;
  const items = user ? serverData?.items ?? [] : guestItems.map((i)=> ({ productId: i.product.id, quantity: i.quantity, product: i.product }));

  return (
    <Layout>
      <h1 className="text-3xl font-extrabold tracking-tight mb-6">Your Cart</h1>
      <div className="grid gap-4">
        {items.map((it)=> (
          <div key={it.productId} className="flex items-center gap-4 rounded-lg border bg-white p-3">
            <img src={it.product.imageUrl} alt={it.product.title} className="h-20 w-20 object-cover rounded"/>
            <div className="flex-1">
              <div className="font-medium">{it.product.title}</div>
              <div className="text-sm text-muted-foreground">Qty: {it.quantity}</div>
            </div>
            <div className="font-semibold">{currency(it.product.price * it.quantity)}</div>
            <Button variant="ghost" onClick={async ()=>{ await remove(it.product.id); await load(); }}>Remove</Button>
          </div>
        ))}
        {items.length === 0 && (
          <div className="text-muted-foreground">Your cart is empty. <Link className="underline" to="/">Browse items</Link>.</div>
        )}
      </div>
      <div className="mt-6 flex items-center justify-between">
        <div className="text-lg font-semibold">Total: {currency(total)}</div>
        {user ? (
          <Button onClick={async ()=>{ await api.checkout(); await load(); await refresh(); }}>Checkout</Button>
        ) : (
          <Button onClick={()=> nav('/login')}>Login to Checkout</Button>
        )}
      </div>
    </Layout>
  );
}
