import { useEffect, useState } from "react";
import { Layout } from "@/components/Layout";
import { api } from "@/lib/api";
import type { Purchase } from "@shared/api";
import { currency } from "@/components/ProductCard";

export default function Purchases() {
  const [list, setList] = useState<Purchase[]>([]);
  useEffect(()=>{ api.purchases().then(r=> setList(r.purchases)); }, []);
  return (
    <Layout>
      <h1 className="text-3xl font-extrabold tracking-tight mb-6">Previous Purchases</h1>
      <div className="space-y-4">
        {list.map((p)=> (
          <div key={p.id} className="rounded-lg border bg-white p-4">
            <div className="flex items-center justify-between">
              <div className="font-medium">Order {p.id.slice(0,8)}</div>
              <div className="text-emerald-700 font-semibold">{currency(p.total)}</div>
            </div>
            <div className="mt-2 text-sm text-muted-foreground">{new Date(p.createdAt).toLocaleString()} · {p.items.length} items</div>
          </div>
        ))}
        {list.length === 0 && (
          <div className="text-muted-foreground">No purchases yet.</div>
        )}
      </div>
    </Layout>
  );
}
