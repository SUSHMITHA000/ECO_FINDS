export const CATEGORIES = [
  "All",
  "Electronics",
  "Fashion",
  "Home",
  "Books",
  "Sports",
  "Toys",
  "Other",
] as const;
