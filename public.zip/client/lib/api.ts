import type {
  AddToCartRequest,
  AuthLoginRequest,
  AuthRegisterRequest,
  AuthResponse,
  CartResponse,
  CreateProductRequest,
  ListProductsResponse,
  Purchase,
  PurchasesResponse,
  UpdateProductRequest,
  User,
} from "@shared/api";

async function http<T>(url: string, opts: RequestInit = {}): Promise<T> {
  const res = await fetch(url, {
    credentials: "include",
    headers: { "Content-Type": "application/json", ...(opts.headers || {}) },
    ...opts,
  });
  if (!res.ok) {
    let msg = "Request failed";
    try { const j = await res.json(); msg = j.error || msg; } catch {}
    throw new Error(msg);
  }
  return (await res.json()) as T;
}

export const api = {
  me: () => http<{ user: User | null }>("/api/auth/me"),
  login: (data: AuthLoginRequest) => http<AuthResponse>("/api/auth/login", { method: "POST", body: JSON.stringify(data) }),
  register: (data: AuthRegisterRequest) => http<AuthResponse>("/api/auth/register", { method: "POST", body: JSON.stringify(data) }),
  logout: () => http<{ ok: boolean }>("/api/auth/logout", { method: "POST" }),

  getProfile: () => http<{ user: User }>("/api/users/me"),
  updateProfile: (data: { username: string }) => http<{ user: User }>("/api/users/me", { method: "PUT", body: JSON.stringify(data) }),

  listProducts: (params: { q?: string; category?: string; mine?: boolean } = {}) => {
    const usp = new URLSearchParams();
    if (params.q) usp.set("q", params.q);
    if (params.category) usp.set("category", params.category);
    if (params.mine) usp.set("mine", "true");
    return http<ListProductsResponse>(`/api/products${usp.toString() ? `?${usp.toString()}` : ""}`);
  },
  getProduct: (id: string) => http<{ product: any }>(`/api/products/${id}`),
  createProduct: (data: CreateProductRequest) => http<{ product: any }>("/api/products", { method: "POST", body: JSON.stringify(data) }),
  updateProduct: (id: string, data: UpdateProductRequest) => http<{ product: any }>(`/api/products/${id}`, { method: "PUT", body: JSON.stringify(data) }),
  deleteProduct: (id: string) => http<{ ok: boolean }>(`/api/products/${id}`, { method: "DELETE" }),

  getCart: () => http<CartResponse>("/api/cart"),
  addToCart: (data: AddToCartRequest) => http<CartResponse>("/api/cart", { method: "POST", body: JSON.stringify(data) }),
  removeFromCart: (productId: string) => http<CartResponse>(`/api/cart/${productId}`, { method: "DELETE" }),
  checkout: () => http<{ purchase: Purchase }>("/api/checkout", { method: "POST" }),
  purchases: () => http<PurchasesResponse>("/api/purchases"),
};
