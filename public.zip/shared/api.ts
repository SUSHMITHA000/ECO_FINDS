/**
 * Shared types for EcoFinds app
 */

export interface DemoResponse {
  message: string;
}

export type ID = string;

export type Category =
  | "Electronics"
  | "Fashion"
  | "Home"
  | "Books"
  | "Sports"
  | "Toys"
  | "Other";

export interface User {
  id: ID;
  email: string;
  username: string;
  createdAt: number;
}

export interface UserPrivate extends User {
  passwordHash: string;
  passwordSalt: string;
}

export interface Session {
  id: ID;
  userId: ID;
  createdAt: number;
  expiresAt: number; // epoch ms
}

export interface Product {
  id: ID;
  ownerId: ID;
  title: string;
  description: string;
  category: Category;
  price: number; // cents
  imageUrl: string; // placeholder or actual
  createdAt: number;
  updatedAt: number;
}

export interface CartItem {
  productId: ID;
  quantity: number;
}

export interface PurchaseItem {
  productId: ID;
  priceAtPurchase: number; // cents
  quantity: number;
}

export interface Purchase {
  id: ID;
  userId: ID;
  items: PurchaseItem[];
  total: number; // cents
  createdAt: number;
}

export interface AuthRegisterRequest {
  email: string;
  password: string;
  username: string;
}

export interface AuthLoginRequest {
  email: string;
  password: string;
}

export interface AuthResponse {
  user: User;
}

export interface UpdateProfileRequest {
  username: string;
}

export interface CreateProductRequest {
  title: string;
  description: string;
  category: Category;
  price: number; // cents
  imageUrl?: string;
}

export interface UpdateProductRequest extends Partial<CreateProductRequest> {}

export interface ListProductsQuery {
  q?: string; // keyword in title
  category?: Category | "All";
  mine?: boolean;
}

export interface ListProductsResponse {
  products: Product[];
}

export interface CartResponse {
  items: (CartItem & { product: Product })[];
  total: number; // cents
}

export interface AddToCartRequest {
  productId: ID;
  quantity?: number;
}

export interface RemoveFromCartRequest {
  productId: ID;
}

export interface PurchasesResponse {
  purchases: Purchase[];
}
